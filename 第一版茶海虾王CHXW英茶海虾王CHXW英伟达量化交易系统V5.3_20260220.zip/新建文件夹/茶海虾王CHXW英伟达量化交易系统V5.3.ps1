<#
茶海虾王CHXW 英伟达 AI · MTK 量化交易系统 V5.3（专业版）
✅ 核心功能：自动买入/持有/卖出、止损止盈、资金管理、日志保存
✅ 界面风格：黑色控制台+绿色专业界面
✅ 使用说明：双击EXE运行，按Ctrl+C停止，日志自动保存到桌面
#>
# 强制设置控制台为黑色背景+绿色标题（专业量化风格）
[Console]::BackgroundColor = "Black"
[Console]::ForegroundColor = "Gray"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ProgressPreference = "SilentlyContinue"

# ========== 【可自定义配置】 ==========
$InitialCapital   = 1000.00    # 初始资金（元）
$MaxPositionRatio = 0.5        # 单票最大仓位比例（50%）
$StopLossRatio    = 0.05       # 止损比例（5%）
$TakeProfitRatio  = 0.08       # 止盈比例（8%）
$MonitorSymbols   = @("sh600000", "sz000001", "sz002594")  # 监控标的
$ExecuteInterval  = 30         # 扫描间隔（秒）
$LogFilePath      = Join-Path $([Environment]::GetFolderPath("Desktop")) "CHXW_MTK_TradeLog_$(Get-Date -f yyyyMMddHHmmss).csv"  # 日志路径

# 本地股票基础数据（代码→名称+基准价格）
$LocalStockData = @{
    "sh600000" = @{Name="浦发银行"; Price=7.80}
    "sz000001" = @{Name="平安银行"; Price=10.20}
    "sz002594" = @{Name="比亚迪"; Price=230.50}
}

# ========== 【账户初始化】 ==========
$Cash            = $InitialCapital
$TotalAssets     = $InitialCapital
$Positions       = @{}
$TradeLogs       = @()
$TotalProfit     = 0.00
$HasOpenPosition = $false
$RunCount        = 0  # 运行轮次计数

# ========== 【启动界面（绿色专业版）】 ==========
Clear-Host
# 绿色标题分隔线
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "              茶海虾王CHXW 英伟达 AI · MTK 量化交易系统 V5.3              " -ForegroundColor Green
Write-Host "============================================================================" -ForegroundColor Green
# 白色基础信息+绿色标识
Write-Host "✅ 初始资金：$($InitialCapital.ToString('N2')) 元" -ForegroundColor Green
Write-Host "✅ 监控标的：$($MonitorSymbols -join '、')" -ForegroundColor Green
Write-Host "✅ 扫描间隔：$ExecuteInterval 秒" -ForegroundColor Green
Write-Host "✅ 单票最大仓位：$($MaxPositionRatio*100)%" -ForegroundColor Green
Write-Host "✅ 止损/止盈：$($StopLossRatio*100)%/$($TakeProfitRatio*100)%" -ForegroundColor Green
Write-Host "`n⚠️  按 Ctrl+C 停止量化交易`n" -ForegroundColor Yellow

# ========== 【核心交易循环】 ==========
$running = $true
while ($running) {
    $RunCount++
    try {
        # 时间分隔线（绿色+轮次）
        Write-Host "`n==================================== [$(Get-Date -f HH:mm:ss)] 第$RunCount轮" -ForegroundColor Green
        
        # 遍历监控标的
        foreach ($code in $MonitorSymbols) {
            # 步骤1：模拟实时股价波动
            $baseData = $LocalStockData[$code]
            if ($baseData) {
                $random = Get-Random -Minimum -0.005 -Maximum 0.005
                $Price = [math]::Round($baseData.Price * (1 + $random), 2)
                $ChangeRatio = [math]::Round(($Price - $baseData.Price) / $baseData.Price, 4)
                $Name = $baseData.Name
            }
            else {
                Write-Host "❌ 无$code数据" -ForegroundColor Red
                continue
            }

            # 步骤2：输出股票实时信息（青色标题+白色内容）
            Write-Host "`n📈 $($Name) ($($code))" -ForegroundColor Cyan
            Write-Host "   现价：$($Price) 元 | 涨跌幅：$($ChangeRatio*100)% | 可用资金：$($Cash.ToString('N2')) 元" -ForegroundColor White

            # 步骤3：交易决策逻辑（洋红色决策）
            if (-not $HasOpenPosition) {
                $decision = "买入"
                Write-Host "   🤖 决策：买入（首次交易）" -ForegroundColor Magenta
            }
            else {
                if ($ChangeRatio -gt 0.005) {
                    $decision = "持有"
                    Write-Host "   🤖 决策：持有（涨幅>0.5%）" -ForegroundColor Magenta
                }
                elseif ($ChangeRatio -lt -0.005) {
                    $decision = "卖出"
                    Write-Host "   🤖 决策：卖出（跌幅>0.5%）" -ForegroundColor Magenta
                }
                else {
                    $decision = "持有"
                    Write-Host "   🤖 决策：持有（波动<0.5%）" -ForegroundColor Magenta
                }
            }

            # 步骤4：执行买入操作（绿色成功提示）
            if ($decision -eq "买入" -and -not $HasOpenPosition) {
                $maxAmount = $TotalAssets * $MaxPositionRatio
                $volume = [math]::Floor($maxAmount / $Price / 100) * 100
                if ($volume -lt 100) {
                    $volume = 100
                    Write-Host "🔧 调整买入数量为最小100股" -ForegroundColor Yellow
                }

                $fee = [math]::Round($Price * $volume * 0.0005, 2)
                $totalCost = [math]::Round($Price * $volume + $fee, 2)

                if ($Cash -ge $totalCost) {
                    $Cash = [math]::Round($Cash - $totalCost, 2)
                    $Positions[$code] = @{
                        Name        = $Name
                        Volume      = $volume
                        CostPrice   = $Price
                        CurrentPrice = $Price
                    }
                    $HasOpenPosition = $true
                    $TotalAssets = [math]::Round($Cash + ($Price * $volume), 2)
                    $TotalProfit = [math]::Round($TotalAssets - $InitialCapital, 2)

                    # 记录交易日志
                    $TradeLogs += [PSCustomObject]@{
                        RunRound   = $RunCount
                        Time       = Get-Date -f "yyyy-MM-dd HH:mm:ss"
                        Type       = "买入"
                        Code       = $code
                        Name       = $Name
                        Price      = $Price
                        Volume     = $volume
                        TotalCost  = $totalCost
                        Fee        = $fee
                        CashAfter  = $Cash
                        Profit     = 0.00
                        Reason     = "首次交易"
                    }

                    Write-Host "✅ 成功买入 $($Name) $($volume)股 | 成本$($Price)元 | 花费$($totalCost)元" -ForegroundColor Green
                }
                else {
                    Write-Host "❌ 资金不足：需$($totalCost)元，可用$($Cash.ToString('N2'))元" -ForegroundColor Red
                }
            }

            # 步骤5：执行卖出操作（绿色成功提示）
            if ($decision -eq "卖出" -and $HasOpenPosition -and $Positions.ContainsKey($code)) {
                $pos = $Positions[$code]
                $volume = $pos.Volume
                $CostPrice = $pos.CostPrice

                $fee = [math]::Round($Price * $volume * 0.0005, 2)
                $totalIncome = [math]::Round($Price * $volume - $fee, 2)
                
                $Cash = [math]::Round($Cash + $totalIncome, 2)
                $Positions.Remove($code)
                $HasOpenPosition = $false

                $profit = [math]::Round($totalIncome - ($CostPrice * $volume), 2)
                $TotalProfit = [math]::Round($TotalProfit + $profit, 2)
                $TotalAssets = $Cash

                # 记录交易日志
                $TradeLogs += [PSCustomObject]@{
                    RunRound   = $RunCount
                    Time       = Get-Date -f "yyyy-MM-dd HH:mm:ss"
                    Type       = "卖出"
                    Code       = $code
                    Name       = $Name
                    Price      = $Price
                    Volume     = $volume
                    TotalIncome = $totalIncome
                    Fee        = $fee
                    CashAfter  = $Cash
                    Profit     = $profit
                    Reason     = "跌幅>0.5%"
                }

                Write-Host "✅ 成功卖出 $($Name) $($volume)股 | 收入$($totalIncome)元 | 盈亏$($profit)元" -ForegroundColor Green
            }

            # 步骤6：止损止盈触发（红色止损+绿色止盈）
            if ($HasOpenPosition -and $Positions.ContainsKey($code)) {
                $pos = $Positions[$code]
                $pos.CurrentPrice = $Price
                $profitRatio = ($Price - $pos.CostPrice) / $pos.CostPrice

                # 止损逻辑（亏损≥5%）
                if ($profitRatio -le -$StopLossRatio) {
                    $volume = $pos.Volume
                    $CostPrice = $pos.CostPrice
                    $fee = [math]::Round($Price * $volume * 0.0005, 2)
                    $totalIncome = [math]::Round($Price * $volume - $fee, 2)
                    
                    $Cash = [math]::Round($Cash + $totalIncome, 2)
                    $Positions.Remove($code)
                    $HasOpenPosition = $false

                    $profit = [math]::Round($totalIncome - ($CostPrice * $volume), 2)
                    $TotalProfit = [math]::Round($TotalProfit + $profit, 2)
                    $TotalAssets = $Cash

                    $TradeLogs += [PSCustomObject]@{
                        RunRound   = $RunCount
                        Time       = Get-Date -f "yyyy-MM-dd HH:mm:ss"
                        Type       = "卖出"
                        Code       = $code
                        Name       = $Name
                        Price      = $Price
                        Volume     = $volume
                        TotalIncome = $totalIncome
                        Fee        = $fee
                        CashAfter  = $Cash
                        Profit     = $profit
                        Reason     = "止损5%"
                    }

                    Write-Host "🔴 止损卖出 $($Name) $($volume)股 | 亏损$($profit)元（≥5%）" -ForegroundColor Red
                }
                # 止盈逻辑（盈利≥8%）
                elseif ($profitRatio -ge $TakeProfitRatio) {
                    $volume = $pos.Volume
                    $CostPrice = $pos.CostPrice
                    $fee = [math]::Round($Price * $volume * 0.0005, 2)
                    $totalIncome = [math]::Round($Price * $volume - $fee, 2)
                    
                    $Cash = [math]::Round($Cash + $totalIncome, 2)
                    $Positions.Remove($code)
                    $HasOpenPosition = $false

                    $profit = [math]::Round($totalIncome - ($CostPrice * $volume), 2)
                    $TotalProfit = [math]::Round($TotalProfit + $profit, 2)
                    $TotalAssets = $Cash

                    $TradeLogs += [PSCustomObject]@{
                        RunRound   = $RunCount
                        Time       = Get-Date -f "yyyy-MM-dd HH:mm:ss"
                        Type       = "卖出"
                        Code       = $code
                        Name       = $Name
                        Price      = $Price
                        Volume     = $volume
                        TotalIncome = $totalIncome
                        Fee        = $fee
                        CashAfter  = $Cash
                        Profit     = $profit
                        Reason     = "止盈8%"
                    }

                    Write-Host "🟢 止盈卖出 $($Name) $($volume)股 | 盈利$($profit)元（≥8%）" -ForegroundColor Green
                }
            }

            # 只处理第一个标的（避免同时持仓多只股票）
            if ($HasOpenPosition) { break }
        }

        # 步骤7：显示账户实时状态（青色标题+白色内容）
        Write-Host "`n💰 模拟账户详情" -ForegroundColor Cyan
        $positionValue = 0
        if ($HasOpenPosition) {
            $Positions.GetEnumerator() | ForEach-Object {
                $positionValue += $_.Value.CurrentPrice * $_.Value.Volume
            }
            $positionValue = [math]::Round($positionValue, 2)
            $TotalAssets = [math]::Round($Cash + $positionValue, 2)
            $TotalProfit = [math]::Round($TotalAssets - $InitialCapital, 2)
        }
        else {
            $positionValue = 0
        }

        Write-Host "   可用现金：$($Cash.ToString('N2')) 元" -ForegroundColor White
        Write-Host "   持仓市值：$($positionValue.ToString('N2')) 元" -ForegroundColor White
        Write-Host "   总资产：$($TotalAssets.ToString('N2')) 元" -ForegroundColor White
        
        $profitColor = if ($TotalProfit -gt 0) { "Green" } else { "Red" }
        Write-Host "   累计盈亏：$($TotalProfit.ToString('N2')) 元" -ForegroundColor $profitColor

        # 显示当前持仓（黄色标题+白色内容）
        if ($HasOpenPosition) {
            Write-Host "`n📦 当前持仓" -ForegroundColor Yellow
            $Positions.GetEnumerator() | ForEach-Object {
                $p = $_.Value
                $profit = [math]::Round(($p.CurrentPrice - $p.CostPrice) * $p.Volume, 2)
                Write-Host "   $($p.Name) | 数量：$($p.Volume) | 成本：$($p.CostPrice) | 现价：$($p.CurrentPrice) | 盈亏：$($profit.ToString('N2')) 元" -ForegroundColor White
            }
        }

        # 步骤8：保存交易日志到桌面（灰色提示）
        if ($TradeLogs.Count -gt 0) {
            $TradeLogs | Export-Csv -Path $LogFilePath -Encoding UTF8 -NoTypeInformation -ErrorAction SilentlyContinue
            Write-Host "`n📝 交易日志已保存：$($LogFilePath)" -ForegroundColor Gray
        }

        # 步骤9：等待下一轮扫描
        Start-Sleep -Seconds $ExecuteInterval -ErrorAction Stop
    }
    catch {
        # 处理Ctrl+C手动停止（黄色提示+绿色总结标题）
        if ($_.Exception.ToString() -match "OperationStoppedException") {
            Write-Host "`n🛑 茶海虾王CHXW 英伟达 MTK 量化系统已停止" -ForegroundColor Yellow
            # 输出交易总结
            Write-Host "`n============================================================================" -ForegroundColor Green
            Write-Host "                          交易总结                     " -ForegroundColor Green
            Write-Host "============================================================================" -ForegroundColor Green
            Write-Host "初始资金：$($InitialCapital.ToString('N2')) 元" -ForegroundColor White
            Write-Host "最终资产：$($TotalAssets.ToString('N2')) 元" -ForegroundColor White
            Write-Host "总盈亏：$($TotalProfit.ToString('N2')) 元" -ForegroundColor (if ($TotalProfit -gt 0) { "Green" } else { "Red" })
            Write-Host "运行轮次：$RunCount 次" -ForegroundColor White
            Write-Host "交易次数：$($TradeLogs.Count) 次" -ForegroundColor White
            Write-Host "日志文件：$LogFilePath" -ForegroundColor White
            Write-Host "============================================================================" -ForegroundColor Green
            $running = $false
        }
        else {
            Write-Host "❌ 运行出错：$($_.Exception.Message)" -ForegroundColor Red
            Start-Sleep -Seconds 5
        }
    }
}
# 保持窗口停留（可选，停止后不自动关闭）
Read-Host -Prompt "`n按Enter键关闭窗口"

